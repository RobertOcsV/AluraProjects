export const environment = {
    apiUrl: 'http://api.jornadamilhas.com'
};
